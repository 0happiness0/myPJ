function showGnb(){
  var tg = document.querySelector(".top");

  tg.classList.toggle("on");
}