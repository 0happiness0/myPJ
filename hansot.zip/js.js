// $(function(){
//   // slide_bg
//   $('.slide_bg').slick({
//     infinite: true,
//     autoplay: true,
//     autoplaySpeed: 4000,
//     pauseOnHover: false
//   });
// });


